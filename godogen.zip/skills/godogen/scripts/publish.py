#!/usr/bin/env python3
"""Publish Godogen runtime files into a target game repo (cross-platform).

Windows-friendly rewrite of the upstream publish.sh: no bash, no rsync,
no mktemp. Pure stdlib so it runs on the managed Python.

Usage:
  python publish.py --engine godot|bevy|babylon [--agent workbuddy|claude|codex]
                    --out <dir> [--force] [--scaffold] [--no-preflight]

What lands in the target repo:
  <manifest>                     runtime manifest (GAME.md / CLAUDE.md / AGENTS.md)
  <engine>.md                    per-engine guide
  <skills_dir>/asset-gen/        asset generation skill + tools
  .gitignore                     (only if absent)
  --scaffold (babylon only)      minimal Vite + TS + Babylon.js project
"""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent  # .../skills/godogen
ENGINES = ("godot", "bevy", "babylon")
AGENTS = ("workbuddy", "claude", "codex")

# Files --force is willing to delete (i.e. "this dir looks like a godogen output")
GENERATED_MARKERS = {
    "GAME.md", "CLAUDE.md", "AGENTS.md", ".workbuddy", ".claude", ".agents", ".codex", ".gitignore",
    # --scaffold output
    "package.json", "package-lock.json", "index.html", "tsconfig.json", "vite.config.ts", "src", "public",
    # game/runtime artifacts that are always safe to regenerate
    "README.md", "assets", "screenshots", "node_modules", "dist", ".git",
}


def load_path_overrides() -> dict[str, str]:
    """Read optional paths.env so tools installed outside PATH (e.g. on E:) still resolve.

    Looks in <skill>/paths.env first, then ~/.godogen/paths.env. Format: KEY=path
    Keys are <BINARY>_BIN, e.g. GODOT_BIN / CARGO_BIN / FFMPEG_BIN / MAGICK_BIN / DOTNET_BIN.
    """
    for cand in (SKILL_ROOT / "paths.env", Path.home() / ".godogen" / "paths.env"):
        if not cand.exists():
            continue
        out: dict[str, str] = {}
        for line in cand.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            out[key.strip().upper()] = value.strip().strip('"')
        return out
    return {}


def resolve(binary: str, overrides: dict[str, str]) -> tuple[str | None, str]:
    """Return (resolved_path_or_None, source_label). paths.env wins over PATH."""
    for key in (f"{binary.upper()}_BIN", binary.upper()):
        if key in overrides:
            p = Path(overrides[key])
            return (str(p), "paths.env") if p.exists() else (None, f"paths.env -> {p} (missing)")
    found = shutil.which(binary)
    return (found, "PATH") if found else (None, "not on PATH")


def preflight(engine: str, overrides: dict[str, str] | None = None) -> list[str]:
    """Report toolchain status, honouring paths.env overrides for off-PATH installs."""
    overrides = overrides or {}
    want = {
        "babylon": [("node", "Node.js 18+/22+ (Babylon + Vite)"), ("npm", "npm")],
        "bevy": [("cargo", "Rust toolchain (cargo)"), ("ffmpeg", "ffmpeg (proof video)")],
        "godot": [("godot", "Godot 4 .NET build"), ("dotnet", ".NET SDK 8+"), ("ffmpeg", "ffmpeg (proof video)")],
    }[engine]
    lines = []
    for binary, label in want:
        found, src = resolve(binary, overrides)
        if found:
            lines.append(f"  ok       {label}  [{src}] {found}")
        else:
            lines.append(f"  MISSING  {label}  ({src}) — set {binary.upper()}_BIN in "
                         f"{SKILL_ROOT / 'paths.env'}")
    return lines


def render(text: str, repl: dict[str, str]) -> str:
    for token, value in repl.items():
        text = text.replace("${" + token + "}", value)
    return text


def render_tree(root: Path, repl: dict[str, str]) -> None:
    for path in root.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        new = render(text, repl)
        if new != text:
            path.write_text(new, encoding="utf-8")


def safe_clean(target: Path) -> None:
    """Only wipe directories that look like a previous godogen publish (or are empty)."""
    if not target.exists():
        return
    entries = list(target.iterdir())
    if not entries:
        return
    unexpected = [p.name for p in entries if p.name not in GENERATED_MARKERS]
    if unexpected:
        sys.exit(
            f"error: --force refused. {target} holds unrelated files: {unexpected}\n"
            "       Refusing to delete. Point --out at an empty/new directory instead."
        )
    for p in entries:
        if p.is_dir():
            shutil.rmtree(p)
        else:
            p.unlink()


def write_scaffold_babylon(target: Path, port: int) -> list[str]:
    """Minimal Vite + TypeScript + Babylon.js project (npm create is interactive)."""
    (target / "src").mkdir(parents=True, exist_ok=True)
    (target / "public").mkdir(parents=True, exist_ok=True)

    (target / "package.json").write_text(
        """{
  "name": "godogen-babylon-game",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc --noEmit && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "@babylonjs/core": "^8.0.0",
    "@babylonjs/loaders": "^8.0.0"
  },
  "devDependencies": {
    "typescript": "^5.6.0",
    "vite": "^6.0.0"
  }
}
""",
        encoding="utf-8",
    )

    (target / "index.html").write_text(
        """<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Godogen Game</title>
    <style>
      html, body { margin: 0; padding: 0; height: 100%; overflow: hidden; background: #101014; }
      #renderCanvas { width: 100%; height: 100%; display: block; touch-action: none; outline: none; }
    </style>
  </head>
  <body>
    <canvas id="renderCanvas"></canvas>
    <script type="module" src="/src/main.ts"></script>
  </body>
</html>
""",
        encoding="utf-8",
    )

    (target / "tsconfig.json").write_text(
        """{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "skipLibCheck": true,
    "noEmit": true,
    "lib": ["ES2022", "DOM"]
  },
  "include": ["src"]
}
""",
        encoding="utf-8",
    )

    (target / "vite.config.ts").write_text(
        f"""import {{ defineConfig }} from "vite";

export default defineConfig({{
  server: {{ host: true, port: {port} }},
}});
""",
        encoding="utf-8",
    )

    (target / "src" / "main.ts").write_text(
        """/** Entry point: engine + scene + render loop. Gameplay belongs in src/ modules. */
import { Engine } from "@babylonjs/core/Engines/engine";
import { Scene } from "@babylonjs/core/scene";
import { ArcRotateCamera } from "@babylonjs/core/Cameras/arcRotateCamera";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { CreateGround } from "@babylonjs/core/Meshes/Builders/groundBuilder";
import { CreateBox } from "@babylonjs/core/Meshes/Builders/boxBuilder";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";

const canvas = document.getElementById("renderCanvas") as HTMLCanvasElement;
const engine = new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true });
const scene = new Scene(engine);
scene.clearColor = new Color4(0.06, 0.06, 0.08, 1);

const camera = new ArcRotateCamera("cam", Math.PI / 3, Math.PI / 3.2, 12, Vector3.Zero(), scene);
camera.attachControl(canvas, true);

new HemisphericLight("light", new Vector3(0, 1, 0), scene).intensity = 0.9;

const ground = CreateGround("ground", { width: 20, height: 20 }, scene);
const groundMat = new StandardMaterial("groundMat", scene);
groundMat.diffuseColor = new Color3(0.18, 0.2, 0.26);
ground.material = groundMat;

const player = CreateBox("player", { size: 1 }, scene);
player.position.y = 0.5;
const playerMat = new StandardMaterial("playerMat", scene);
playerMat.diffuseColor = new Color3(0.95, 0.45, 0.2);
player.material = playerMat;

// Simple WASD/arrow movement, driven by engine delta (no fixed framerate assumed).
const keys = new Set<string>();
addEventListener("keydown", (e) => keys.add(e.key.toLowerCase()));
addEventListener("keyup", (e) => keys.delete(e.key.toLowerCase()));

const SPEED = 4; // units / second
scene.onBeforeRenderObservable.add(() => {
  const dt = engine.getDeltaTime() / 1000;
  if (keys.has("w") || keys.has("arrowup")) player.position.z += SPEED * dt;
  if (keys.has("s") || keys.has("arrowdown")) player.position.z -= SPEED * dt;
  if (keys.has("a") || keys.has("arrowleft")) player.position.x -= SPEED * dt;
  if (keys.has("d") || keys.has("arrowright")) player.position.x += SPEED * dt;
  camera.setTarget(player.position);
});

engine.runRenderLoop(() => scene.render());
addEventListener("resize", () => engine.resize());

// Ready flag: headless capture waits on this so screenshots are never blank.
(window as unknown as { __GAME_READY__: boolean }).__GAME_READY__ = true;
""",
        encoding="utf-8",
    )

    return ["package.json", "index.html", "tsconfig.json", "vite.config.ts", "src/main.ts"]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Publish Godogen runtime into a game repo.")
    ap.add_argument("--engine", choices=ENGINES, required=True)
    ap.add_argument("--agent", choices=AGENTS, default="workbuddy")
    ap.add_argument("--out", required=True, help="target game repo directory")
    ap.add_argument("--force", action="store_true", help="wipe a previous godogen publish in the target")
    ap.add_argument("--scaffold", action="store_true", help="also write a minimal project scaffold (babylon only)")
    ap.add_argument("--port", type=int, default=5173, help="dev server port for the babylon scaffold")
    ap.add_argument("--no-preflight", action="store_true", help="skip toolchain checks")
    args = ap.parse_args(argv)

    engine_display = {"godot": "Godot", "bevy": "Bevy", "babylon": "Babylon.js"}[args.engine]
    runtime_asset_dir = "src/assets" if args.engine == "babylon" else "assets"

    if args.agent == "workbuddy":
        manifest, skills_rel = "GAME.md", ".workbuddy/skills"
        asset_cmd = "asset-gen skill"
    elif args.agent == "claude":
        manifest, skills_rel = "CLAUDE.md", ".claude/skills"
        asset_cmd = "/asset-gen"
    else:
        manifest, skills_rel = "AGENTS.md", ".agents/skills"
        asset_cmd = "$asset-gen"

    asset_skill_dir = f"{skills_rel}/asset-gen"
    engine_guide = f"{args.engine}.md"

    if not args.no_preflight:
        overrides = load_path_overrides()
        print(f"Preflight ({engine_display}):")
        for line in preflight(args.engine, overrides):
            print(line)
        if overrides:
            print(f"  (path overrides loaded: {', '.join(sorted(overrides))})")
        print()

    target = Path(args.out).expanduser().resolve()
    if args.force:
        safe_clean(target)
    target.mkdir(parents=True, exist_ok=True)

    repl = {
        "ENGINE_NAME": engine_display,
        "ENGINE_GUIDE_FILE": engine_guide,
        "ASSET_SKILL_COMMAND": asset_cmd,
        "ASSET_GEN_SKILL_DIR": asset_skill_dir,
        "RUNTIME_ASSET_DIR": runtime_asset_dir,
        "AGENT_NAME": args.agent.capitalize(),
    }

    # --- asset-gen skill (rendered copy of the bundled template + tools) ---
    skills_out = target / skills_rel / "asset-gen"
    if skills_out.exists():
        shutil.rmtree(skills_out)
    skills_out.mkdir(parents=True, exist_ok=True)
    (skills_out / "tools").mkdir()

    template = SKILL_ROOT / "references" / "asset-gen-template.md"
    (skills_out / "SKILL.md").write_text(render(template.read_text(encoding="utf-8"), repl), encoding="utf-8")
    for f in (SKILL_ROOT / "tools").glob("*.py"):
        shutil.copy2(f, skills_out / "tools" / f.name)
    shutil.copy2(SKILL_ROOT / "tools" / "requirements.txt", skills_out / "tools" / "requirements.txt")
    (skills_out / "rembg.md").write_text(
        render((SKILL_ROOT / "references" / "rembg.md").read_text(encoding="utf-8"), repl), encoding="utf-8"
    )
    print(f"Installed asset-gen skill -> {skills_rel}/asset-gen")

    # --- manifest ---
    (target / manifest).write_text(
        render((SKILL_ROOT / "references" / "runtime-template.md").read_text(encoding="utf-8"), repl),
        encoding="utf-8",
    )
    print(f"Created {manifest}")

    # --- engine guide ---
    shutil.copy2(SKILL_ROOT / "references" / "engines" / f"{args.engine}.md", target / engine_guide)
    print(f"Created {engine_guide}")

    # --- optional scaffold ---
    if args.scaffold:
        if args.engine != "babylon":
            print("note: --scaffold currently only supports babylon; skipped")
        else:
            for f in write_scaffold_babylon(target, args.port):
                print(f"Created {f}")

    # --- .gitignore ---
    gi = target / ".gitignore"
    if not gi.exists():
        lines = [".workbuddy", manifest, engine_guide] if args.agent == "workbuddy" else ([".claude", manifest, engine_guide] if args.agent == "claude" else [".agents", manifest, ".codex", engine_guide])
        lines += {
            "godot": ["assets", "screenshots", ".godot", "*.import", "bin/", "obj/"],
            "bevy": ["/target", "/screenshots"],
            "babylon": ["/node_modules", "/dist", "/screenshots"],
        }[args.engine]
        gi.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print("Created .gitignore")

    print(f"\nDone. {engine_display} / {args.agent} published to: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
