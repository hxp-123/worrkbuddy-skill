---
name: godogen
description: "Autonomous game development — describe a game in one sentence and this builds it end to end (Godot / Bevy / Babylon.js), generates its art assets (Gemini / Grok images, Tripo3D GLB models, rigged characters, animated sprites), runs the engine, and proves the result with a live URL or a recorded video. Use when the user asks to 做个游戏 / build a game / 用 Godot|Bevy|Babylon.js 做游戏 / 生成游戏素材 / 生成 3D 模型 GLB / 生成角色动画精灵图, or wants an agent to autonomously develop and verify a playable game."
agent_created: true
---

# Godogen — 自主游戏开发

描述一个游戏，agent 负责：搭工程 → 写玩法 → 生成美术素材 → 跑起来 → **用运行中的画面自证**（不是"编译通过"就算完）。

来源：[github.com/htdt/godogen](https://github.com/htdt/godogen)（原为 Claude Code / Codex 设计，本副本已改造为 WorkBuddy + Windows 可用）。

## 工作流（第 0 步永远是 publish）

Godogen **不是**一个装好就能直接写游戏的模板，它是一个"生成器"：先把运行时文件发布到一个全新的游戏仓库，然后 agent 在那个仓库里造游戏。

```
godogen(本 skill)  →  游戏仓库(GAME.md + 引擎指南 + asset-gen 技能)  →  真正的游戏
```

```bash
PY="C:/Users/h/.workbuddy/binaries/python/versions/3.13.12/python.exe"
SK="C:/Users/h/.workbuddy/skills/godogen"

"$PY" "$SK/scripts/publish.py" --engine babylon --agent workbuddy --out ./my-game --scaffold
```

参数：`--engine godot|bevy|babylon` · `--agent workbuddy|claude|codex` · `--out <dir>` · `--force`（只清理上次 godogen 发布过的目录，遇无关文件会拒绝）· `--scaffold`（babylon 专用，顺带生成 Vite+TS+Babylon 最小工程）· `--port 5173` · `--no-preflight`。

发布后进入 `<out>` 目录干活，读 `GAME.md` 和 `<engine>.md` 开工。

## 选引擎（先看本机有什么）

运行 publish.py 会先做 preflight 检查。本机实测（2026-09-08）：

| 引擎 | 依赖 | 本机状态 | 说明 |
|------|------|----------|------|
| **Babylon.js** | Node 22 + npm | ✅ 全齐 | node v22.22.2 / npm 10.9.7。浏览器里跑，用户直接看 URL，最省事 |
| **Godot 4** | Godot .NET 版 + .NET SDK | ✅ 全齐 | Godot 4.7.2 mono + SDK 8.0.424 + ffmpeg 都到位（见下） |
| Bevy | Rust/cargo | ❌ 未安装 | 需 rustup + VS Build Tools 4–7 GB + `target/` 3–8 GB，性价比低 |
| — | ImageMagick (`magick`) | ❌ 未安装 | 统一图片尺寸用（图片帧 1024 vs 视频帧 720），可用 ffmpeg 替代 |

缺 `ffmpeg`（录验证视频）和 `magick`/ImageMagick（改尺寸）时，publish 会警告但继续。

### 工具装在 PATH 之外（比如 E 盘）怎么办

preflight 默认用 `which` 找命令，装到非 PATH 目录会报 MISSING。两种解法：

1. **写 `paths.env`**（推荐，不用动系统环境变量）。复制 `paths.env.example` 为同目录的 `paths.env`，或放 `~/.godogen/paths.env`：
   ```
   GODOT_BIN=E:/Godot/Godot_v4.7.2-stable_mono_win64.exe
   DOTNET_BIN=E:/dotnet/dotnet.exe
   FFMPEG_BIN=E:/ffmpeg/bin/ffmpeg.exe
   ```
   `paths.env` 优先级高于 PATH，且解析结果会打印出来。
2. 或者把目录加进用户 PATH（`setx PATH "..."`），需重开 WorkBuddy 会话才生效。

**注意**：本机**不是管理员**，`winget install` 装 .NET SDK 会卡在 UAC。改用微软官方脚本装到用户目录：
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force   # 必加，否则禁止运行脚本
.\dotnet-install.ps1 -Channel 8.0 -Architecture x64 -InstallDir C:\Users\h\dotnet   # -Architecture 必加，否则报 "Architecture '' not supported"
[System.Environment]::SetEnvironmentVariable('DOTNET_ROOT','C:\Users\h\dotnet','User')
```
Godot 是绿色 zip，解压即用免安装，放哪个盘都行，记得写进 `paths.env`。

## 核心原则：证明，而不是声称

- **判断进度只看运行中的游戏**，不看编译是否干净。
- 结构性问题自己验（能加载、无报错、素材在位），画面问题驱动下一轮迭代。
- 用户没亲眼看到它跑起来 → 收尾必须录一段 15–20 秒的视频，并且**自己先看一遍**再交付。
- Babylon.js 的 dev server 绑 `0.0.0.0` 固定端口，把 `http://<host>:5173` 交给用户，你改他刷新。

## 生成美术素材（asset-gen）

publish 后游戏仓库里会有 `.workbuddy/skills/asset-gen/`（含 SKILL.md 与 tools）。**这些是付费 API**，每次调用都真花钱，动手前先跟用户确认预算。

环境要求（三个 key，缺哪个就用不了哪个后端）：

```bash
GOOGLE_API_KEY=...    # Gemini 生图   https://aistudio.google.com/
XAI_API_KEY=...       # Grok 生图/生视频  https://console.x.ai/home
TRIPO3D_API_KEY=...   # Tripo3D 图片转 3D  https://platform.tripo3d.ai/
```

Python 依赖（独立 venv，见下方"已配置环境"）：`xai-sdk` `google-genai` `requests` `numpy` `pillow`（抠图还需 `rembg` `pymatting` `onnxruntime-gpu`，体积大且需 CUDA，按需装）。

```bash
PY="C:/Users/h/.workbuddy/binaries/python/envs/godogen/Scripts/python.exe"   # 或 versions/3.13.12/python.exe
T="C:/Users/h/.workbuddy/skills/godogen/tools"                                # 用户级；仓库内为 .workbuddy/skills/asset-gen/tools

"$PY" "$T/asset_gen.py" image --prompt "..." -o assets/img/car.png            # 默认 grok 2¢
"$PY" "$T/asset_gen.py" image --model gemini --size 1K --prompt "..." -o p.png # Gemini 7¢，指令遵循更准
"$PY" "$T/asset_gen.py" image --prompt "换个姿势" --image ref.png -o p2.png     # 图生图
"$PY" "$T/asset_gen.py" video --image pose.png --duration 2 -o walk.mp4        # 5¢/秒
"$PY" "$T/asset_gen.py" glb   --image ref.png -o model.glb                     # 30¢（--quality hd 60¢）
"$PY" "$T/asset_gen.py" rig   --image ref.png -o rigged.glb                    # 仅人形，+25¢
"$PY" "$T/asset_gen.py" retarget --rigged rigged.glb --animation preset:biped:walk -o walk.glb  # 10¢
"$PY" "$T/asset_gen.py" resume -o model.glb                                    # 超时后续跑，不重复扣费
```

输出是 JSON：`{"ok": true, "path": "...", "cost_cents": 7}`；进度走 stderr（重定向到临时文件，失败再看）。

省钱与避坑要点（完整版见 `references/asset-gen-template.md`）：

- **Grok 2¢ 便宜但不太听指令**（适合纹理、小物件、背景）；**Gemini 贵但精准**（角色、参考图、布局必须用它）。
- **Tripo3D 超时 ≠ 失败**：task id 已存在 `.tripo.json` 里，**别重提，会重复扣费**，用 `resume` 免费续。
- 转 GLB 前**必须先看图**，烂图转 3D 等于白扔 30¢+。
- 不要 prompt "透明背景"（会生成棋盘格），用纯色底再用 rembg 抠。
- 方向/朝向不可靠：生成一次，运行时水平翻转，别花钱生成镜像。
- 每个素材在 README 里登记**游戏内尺寸**（米 / 像素），否则写代码的人一定缩放错。

## 目录

```
references/runtime-template.md      运行时清单模板（发布后成 GAME.md）
references/engines/{godot,bevy,babylon}.md   三份引擎指南
references/asset-gen-template.md    素材生成技能全文（发布后成仓库内 skill）
references/rembg.md                 抠图说明
scripts/publish.py                  跨平台发布脚本（替代上游 publish.sh）
tools/asset_gen.py tripo3d.py find_loop_frame.py grid_slice.py rembg_matting.py
```

## 已配置环境（本机实测，2026-09-08）

- 托管 Python：`C:\Users\h\.workbuddy\binaries\python\versions\3.13.12\python.exe`；素材专用 venv：`C:\Users\h\.workbuddy\binaries\python\envs\godogen`（162 MB）
- **Godot 4.7.2 .NET**：`C:\Users\h\Godot\Godot_v4.7.2-stable_mono_win64\Godot_v4.7.2-stable_mono_win64.exe`（258 MB，绿色解压免安装）。验证：`godot --version` → `4.7.2.stable.mono.official.ed1daf0bf`
- **.NET SDK 8.0.424**：`C:\Users\h\dotnet`（727 MB，C 盘，非管理员装）。`DOTNET_ROOT` 与用户 PATH 已设；**本会话 PATH 仍指向旧的 `C:\Program Files\dotnet`（只有 runtime 没 SDK）**，故 `paths.env` 里写了 `DOTNET_BIN` 覆盖。重开 WorkBuddy 后该项可删。
- **ffmpeg**：`C:\Users\h\ffmpeg\ffmpeg-master-latest-win64-gpl\bin\ffmpeg.exe`（431 MB，BtbN 构建）。**gyan.dev 极慢（~120 KB/s，10 分钟只下 64%）**，改用 GitHub 的 BtbN 构建 4 分钟下完。
- Node：`C:\Users\h\.workbuddy\binaries\node\versions\22.22.2-2\node.exe`
- 上游原版 `publish.sh` 依赖 `rsync`，Windows Git Bash 没有 → **已用 `scripts/publish.py` 取代**，不要再用 .sh 版本。
