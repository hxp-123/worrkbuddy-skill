#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_hex.py - 把 51 单片机 C 源码编译为 Intel HEX（Proteus 可直接加载）。

优先使用本机 Keil C51 命令行工具链，其次 SDCC（自动把 Keil 语法转成 SDCC 语法）。

用法:
    python build_hex.py <源文件> [-o 输出名]
    python build_hex.py "E:\\keil51\\PPPPPP\\1" -o led
产出: <源文件所在目录>\\<输出名>.hex
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

C51_ROOTS = [
    r"E:\keil51", r"E:\Keil.v5", r"C:\Keil_v5", r"C:\Keil",
    r"D:\keil51", r"D:\Keil_v5", r"E:\Keil C51",
]
SDCC_CANDIDATES = [
    r"C:\Program Files\SDCC\bin\sdcc.exe",
    r"C:\Program Files (x86)\SDCC\bin\sdcc.exe",
]


def find_c51():
    for root in C51_ROOTS:
        exe = Path(root) / "C51" / "BIN" / "C51.EXE"
        if exe.exists():
            return exe
    return None


def find_sdcc():
    for p in SDCC_CANDIDATES:
        if Path(p).exists():
            return Path(p)
    which = shutil.which("sdcc")
    return Path(which) if which else None


def read_source(path):
    raw = path.read_bytes()
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def keil_to_sdcc(src):
    out = re.sub(r"#include\s*[<\"]reg52\.h[>\"]", "#include <at89x52.h>", src, flags=re.I)
    out = re.sub(r"#include\s*[<\"]reg51\.h[>\"]", "#include <at89x51.h>", out, flags=re.I)
    out = re.sub(r"#include\s*[<\"]reg5[12]\.h[>\"]", "#include <at89x52.h>", out, flags=re.I)

    def sbit_repl(m):
        return "#define %s P%s_%s" % (m.group(1), m.group(2), m.group(3))

    out = re.sub(r"^\s*sbit\s+(\w+)\s*=\s*P([0-3])\^([0-7])\s*;", sbit_repl, out, flags=re.M)
    return out


def ascii_safe(d):
    try:
        str(d).encode("ascii")
    except UnicodeEncodeError:
        return False
    return " " not in str(d)


def run(cmd, cwd, env=None):
    r = subprocess.run(cmd, cwd=str(cwd), env=env, capture_output=True, text=True, errors="replace")
    out = ((r.stdout or "") + (r.stderr or "")).strip()
    if out:
        print("\n".join(out.splitlines()[-6:]))
    return r


def build_c51(c51, main_c, workdir, name):
    inc = c51.parents[2] / "INC"
    run([str(c51), main_c.name, "INCDIR(%s)" % inc], workdir)
    obj = workdir / (main_c.stem + ".OBJ")
    if not obj.exists():
        sys.exit("[x] Keil C51 编译失败（上方为编译器输出），请把输出发给助手排查")
    run([str(c51.parent / "BL51.EXE"), obj.name, "TO", name], workdir)
    run([str(c51.parent / "OH51.EXE"), name], workdir)
    hexfile = workdir / (name + ".hex")
    if not hexfile.exists():
        sys.exit("[x] BL51/OH51 未生成 hex，请把上方输出发给助手排查")
    return hexfile


def build_sdcc(sdcc, c_text, workdir, name):
    cfile = workdir / "src_conv.c"
    cfile.write_text(keil_to_sdcc(c_text), encoding="utf-8")
    env = os.environ.copy()
    # 关键: sdcpp 通过 PATH 查找 cc1，必须把 SDCC bin 放进 PATH
    env["PATH"] = str(sdcc.parent) + os.pathsep + env.get("PATH", "")
    run([str(sdcc), "-mmcs51", "--model-small", cfile.name], workdir, env)
    ihx = workdir / "src_conv.ihx"
    if not ihx.exists():
        sys.exit("[x] SDCC 编译失败（上方为编译器输出），请把输出发给助手排查")
    packihx = sdcc.parent / "packihx.exe"
    hexfile = workdir / (name + ".hex")
    with open(hexfile, "w", newline="\n") as f:
        subprocess.run([str(packihx), ihx.name], cwd=str(workdir), stdout=f, check=True)
    return hexfile


def main():
    ap = argparse.ArgumentParser(description="51 单片机 C 源码 -> Proteus 可用 HEX")
    ap.add_argument("source", help="C 源文件（允许无后缀）")
    ap.add_argument("-o", "--output", default=None, help="输出名（默认与源文件同名）")
    args = ap.parse_args()

    src = Path(args.source).resolve()
    if not src.exists():
        sys.exit("[x] 找不到源文件: %s" % src)
    if src.suffix.lower() not in (".c", ".h") and src.suffix != "":
        print("[!] 提示: 源文件后缀是 %s，可能不是 C 源码" % src.suffix)
    name = re.sub(r"[^\w-]", "_", args.output or src.stem) or "led"

    text = read_source(src)
    c51, sdcc = find_c51(), find_sdcc()

    workdir = src.parent if ascii_safe(src.parent) else Path(tempfile.mkdtemp(prefix="hexbuild_"))
    stem = src.stem if re.fullmatch(r"[A-Za-z_]\w*", src.stem) else "main"
    main_c = workdir / (stem + ".c")
    main_c.write_text(text, encoding="gbk", errors="replace")

    if c51:
        print("[i] 使用 Keil C51: %s" % c51)
        hexfile = build_c51(c51, main_c, workdir, name)
    elif sdcc:
        print("[i] 未找到 Keil C51，使用 SDCC: %s" % sdcc)
        hexfile = build_sdcc(sdcc, text, workdir, name)
    else:
        sys.exit("[x] 本机没有 Keil C51 也没有 SDCC。\n"
                 "    可先安装 SDCC:  winget install --id SDCC.SDCC")

    dest = src.parent / hexfile.name
    if hexfile.resolve() != dest.resolve():
        shutil.copy2(hexfile, dest)
    size = dest.stat().st_size
    print()
    print("[OK] 已生成: %s (%d 字节)" % (dest, size))
    print("[i] Proteus 用法: 双击单片机 -> Program File 选这个 .hex -> Clock Frequency 填晶振频率 -> 运行")
    print("[i] 注意: C51 评估版程序入口在 0x0800，仅适用于 ROM>2KB 的芯片（AT89C52 可以）")


if __name__ == "__main__":
    main()
