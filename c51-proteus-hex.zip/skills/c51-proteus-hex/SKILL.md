---
name: c51-proteus-hex
description: 把 51 单片机 C 源码一键编译成 Proteus 可加载的 Intel HEX 文件。当用户说"编译 hex"、"Proteus 里点不亮/找不到程序"、"reg52.h"、"sbit"、"帮我把代码变成单片机能用的文件"、保存的源码无法在 Proteus 中使用时使用。自动优先调用本机 Keil C51，其次 SDCC（自动把 Keil 语法转成 SDCC 语法），并修复常见环境坑。
---

# C51 源码 → Proteus 可用 HEX

## 什么时候用

用户手上有 51 单片机（AT89C52/STC89C52 等）的 C 源码，需要在 Proteus 仿真里运行。
**核心认知：Proteus 只认编译后的 .hex，用户"保存"的源码（尤其没有 .c 后缀的）永远不能直接用。**

## 快速用法

```bash
python <skill目录>/scripts/build_hex.py <源文件路径> [-o 输出名]
# 例：用户把代码存成了无后缀文件
python scripts/build_hex.py "E:\keil51\PPPPPP\1" -o led
# 产出 E:\keil51\PPPPPP\led.hex
```

成功后告诉用户 Proteus 三步：双击单片机 → Program File 选 .hex（对话框文件类型要切到 Hex Files）→ Clock Frequency 填与晶振一致（如 11.0592MHz）→ ▶ 运行。

## 编译器选择逻辑（脚本已自动处理）

1. **优先 Keil C51 命令行**：在 E:\keil51、E:\Keil.v5、C:\Keil_v5 等常见位置找 `C51\BIN\C51.EXE`，流水线 `C51.EXE → BL51.EXE → OH51.EXE`，Keil 语法源码（reg52.h / sbit P1^7）原样编译。
2. **其次 SDCC**：找不到 Keil 时自动把 Keil 语法转成 SDCC 语法再编译：
   - `#include <reg52.h>` → `<at89x52.h>`（reg51→at89x51，兼容尖括号和引号）
   - `sbit LED = P1^7;` → `#define LED P1_7`
3. **都没有**：提示 `winget install --id SDCC.SDCC` 安装 SDCC。

## 已踩过的坑（排查必读）

- **SDCC 4.5.0 打包 bug**：`bin\cc1` 漏了 .exe 后缀；且 sdcpp 靠 **PATH** 找 cc1 —— 调用前必须把 SDCC 的 bin 加入 PATH（脚本已做）。报错 `cannot execute 'cc1'` 就是这两个原因。
- **源文件没有后缀**：用户常把代码存成无后缀文件。脚本自动复制成 .c 再编。
- **编码**：用户文件常是 GBK，脚本按 utf-8→gbk 顺序探测；给 C51 喂 GBK 编码的 .c。
- **路径含中文/空格**：Keil C51 命令行会挂，脚本自动切到临时 ASCII 目录编译再拷回。
- **C51 评估版**：0 错误也会把程序入口放到 0x0800（复位 LJMP 过去），只适用于 ROM > 2KB 的芯片（AT89C52 8KB 没问题）；AT89C51（4KB）也没问题，但 2KB 芯片（AT89C2051）不能用。
- **用户装错 Keil**：MDK（只有 ARM 文件夹）编不了 51。判断标准：目录下有没有 `C51\BIN\C51.EXE`。MDK 与 C51 可共存（如 E:\Keil.v5 与 E:\keil51）。
- **保存 ≠ 编译**：改完代码必须重新编译，Proteus 里才加载得到新 hex。

## 安全审计记录（2026-09-10，P2 通过）

- 仅本地文件操作 + 调用本机编译器；无网络请求、无 eval/exec 任意输入、无敏感信息。
- 唯一外部建议动作是 `winget install SDCC.SDCC`（官方源），需用户确认。
